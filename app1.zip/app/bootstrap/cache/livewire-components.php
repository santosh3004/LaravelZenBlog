<?php return array (
  'comments' => 'App\\Http\\Livewire\\Comments',
  'counter' => 'App\\Http\\Livewire\\Counter',
  'lara-file-upload' => 'App\\Http\\Livewire\\LaraFileUpload',
);