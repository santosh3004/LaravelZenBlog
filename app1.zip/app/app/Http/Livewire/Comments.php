<?php

namespace App\Http\Livewire;

use Livewire\Component;

use Carbon\Carbon;

use App\Models\Comment;
use Livewire\WithFileUploads;
use Livewire\WithPagination;

class Comments extends Component
{
    use WithPagination;

    public $newcomment;

    //real time validation
    public function updated($field)
    {
        $this->validateOnly($field,['newcomment'=>'required|max:255']);
    }

    public function addcomment()
    {
        $this->validate(['newcomment'=>'required|max:255']);


        $created_comment = Comment::create([
            'body'=>$this->newcomment,
            'user_id'=>1
        ]);

        $this->newcomment = "";

        session()->flash('message','Comment added successfully.');
    }


    public function mount()
    {
        // $comments = new Comment;
        // $comments = $comments->latest()->paginate(5);
        // $this->comments = $comments;
    }

    public function remove($id)
    {
        $comments = new Comment;
        $comments = $comments->where('id',$id)->first();

        $comments->delete();

        session()->flash('message','Comment deleted successfully.');
    }

    public function render()
    {
        return view('livewire.comments',[
            'comments' => Comment::latest()->paginate(2)
        ]);
    }
}


