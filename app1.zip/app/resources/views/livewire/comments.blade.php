<div>

    <div class="container">
        <h1>Comments</h1>
        @if(session()->has('message'))
        <div class="alert alert-primary" role="alert">
            <strong>{{ session('message') }}</strong>
        </div>
        @endif
        <form action="" wire:submit.prevent="addcomment">
            <div class="form-group">
                <input type="text" class="form-control" name="" id="" aria-describedby="helpId" placeholder="" wire:model.debounce.500ms="newcomment">
                @error('newcomment')
                <p class="form-text text-warning">
                    {{$message}}
                </p>
                @enderror
                <br>
                <button type="submit">Add</button>
              </div>
        </form>

        @foreach($comments as $comment)
        <div class="card-deck">
            <div class="card">
                <img class="card-img-top" src="holder.js/100x180/" alt="">
                <div class="card-body">
                    <p class="form-text text-muted">
                        {{$comment->created_at->diffForHumans()}}
                    </p>
                    <h4 class="card-title">{{$comment->creator->name}}</h4>
                    <p class="card-text">{{$comment->body}}</p>

                    <button wire:click="remove({{$comment->id}})">Delete</button>
                </div>
            </div>
        </div>
        @endforeach

        {{$comments->links('pagination-links')}}
    </div>

</div>

