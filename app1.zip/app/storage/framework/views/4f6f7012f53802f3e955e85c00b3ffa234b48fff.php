<div style="text-align: center;">
    <button wire:click="increment">+</button>
    <h1><?php echo e($count); ?></h1>
    <button wire:click="decrement">-</button>
</div>
<?php /**PATH E:\wampp\www\livewireprojects\app\resources\views/livewire/counter.blade.php ENDPATH**/ ?>