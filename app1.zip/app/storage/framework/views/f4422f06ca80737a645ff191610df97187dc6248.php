<div>

    <div class="container">
        <h1>Comments</h1>
        <?php if(session()->has('message')): ?>
        <div class="alert alert-primary" role="alert">
            <strong><?php echo e(session('message')); ?></strong>
        </div>
        <?php endif; ?>
        <form action="" wire:submit.prevent="addcomment">
            <div class="form-group">
                <input type="text" class="form-control" name="" id="" aria-describedby="helpId" placeholder="" wire:model.debounce.500ms="newcomment">
                <?php $__errorArgs = ['newcomment'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p class="form-text text-warning">
                    <?php echo e($message); ?>

                </p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <br>
                <button type="submit">Add</button>
              </div>
        </form>

        <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card-deck">
            <div class="card">
                <img class="card-img-top" src="holder.js/100x180/" alt="">
                <div class="card-body">
                    <p class="form-text text-muted">
                        <?php echo e($comment->created_at->diffForHumans()); ?>

                    </p>
                    <h4 class="card-title"><?php echo e($comment->creator->name); ?></h4>
                    <p class="card-text"><?php echo e($comment->body); ?></p>

                    <button wire:click="remove(<?php echo e($comment->id); ?>)">Delete</button>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php echo e($comments->links('pagination-links')); ?>

    </div>

</div>

<?php /**PATH E:\wampp\www\livewireprojects\app\resources\views/livewire/comments.blade.php ENDPATH**/ ?>